#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=C:\Users\hp\Downloads\flutter_windows_3.41.6-stable\flutter"
export "FLUTTER_APPLICATION_PATH=C:\Users\hp\Downloads\flutter_windows_3.41.6-stable\profile_card\nav_bar\3rd_exercise\fourth_exercise\flutter_application_1"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
